﻿namespace FormulasVolumen
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCube = new System.Windows.Forms.Button();
            this.btnSphere = new System.Windows.Forms.Button();
            this.btnCylinder = new System.Windows.Forms.Button();
            this.btnCubeA = new System.Windows.Forms.Button();
            this.btnSphereA = new System.Windows.Forms.Button();
            this.btnCylinderA = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.txtHeight = new System.Windows.Forms.TextBox();
            this.txtLenght = new System.Windows.Forms.TextBox();
            this.txtWidth = new System.Windows.Forms.TextBox();
            this.txtRadius = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCube
            // 
            this.btnCube.Location = new System.Drawing.Point(86, 180);
            this.btnCube.Name = "btnCube";
            this.btnCube.Size = new System.Drawing.Size(109, 46);
            this.btnCube.TabIndex = 0;
            this.btnCube.Text = "Cube";
            this.btnCube.UseVisualStyleBackColor = true;
            this.btnCube.Click += new System.EventHandler(this.BtnCube_Click);
            // 
            // btnSphere
            // 
            this.btnSphere.Location = new System.Drawing.Point(331, 180);
            this.btnSphere.Name = "btnSphere";
            this.btnSphere.Size = new System.Drawing.Size(109, 46);
            this.btnSphere.TabIndex = 1;
            this.btnSphere.Text = "Sphere";
            this.btnSphere.UseVisualStyleBackColor = true;
            this.btnSphere.Click += new System.EventHandler(this.BtnSphere_Click);
            // 
            // btnCylinder
            // 
            this.btnCylinder.Location = new System.Drawing.Point(573, 180);
            this.btnCylinder.Name = "btnCylinder";
            this.btnCylinder.Size = new System.Drawing.Size(109, 46);
            this.btnCylinder.TabIndex = 2;
            this.btnCylinder.Text = "Cylinder";
            this.btnCylinder.UseVisualStyleBackColor = true;
            this.btnCylinder.Click += new System.EventHandler(this.BtnCylinder_Click);
            // 
            // btnCubeA
            // 
            this.btnCubeA.Location = new System.Drawing.Point(86, 322);
            this.btnCubeA.Name = "btnCubeA";
            this.btnCubeA.Size = new System.Drawing.Size(109, 46);
            this.btnCubeA.TabIndex = 3;
            this.btnCubeA.Text = "Cube";
            this.btnCubeA.UseVisualStyleBackColor = true;
            this.btnCubeA.Click += new System.EventHandler(this.BtnCubeA_Click);
            // 
            // btnSphereA
            // 
            this.btnSphereA.Location = new System.Drawing.Point(331, 322);
            this.btnSphereA.Name = "btnSphereA";
            this.btnSphereA.Size = new System.Drawing.Size(109, 46);
            this.btnSphereA.TabIndex = 4;
            this.btnSphereA.Text = "Sphere";
            this.btnSphereA.UseVisualStyleBackColor = true;
            this.btnSphereA.Click += new System.EventHandler(this.BtnSpehereA_Click);
            // 
            // btnCylinderA
            // 
            this.btnCylinderA.Location = new System.Drawing.Point(573, 322);
            this.btnCylinderA.Name = "btnCylinderA";
            this.btnCylinderA.Size = new System.Drawing.Size(121, 46);
            this.btnCylinderA.TabIndex = 5;
            this.btnCylinderA.Text = "Cylinder";
            this.btnCylinderA.UseVisualStyleBackColor = true;
            this.btnCylinderA.Click += new System.EventHandler(this.BtnCylinderA_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 277);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 25);
            this.label1.TabIndex = 6;
            this.label1.Text = "Superficial Area";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 25);
            this.label2.TabIndex = 7;
            this.label2.Text = "Volume";
            this.label2.Click += new System.EventHandler(this.Label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(187, 446);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 25);
            this.label3.TabIndex = 8;
            this.label3.Text = "Result: ";
            // 
            // lblResult
            // 
            this.lblResult.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblResult.Location = new System.Drawing.Point(294, 446);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(236, 44);
            this.lblResult.TabIndex = 9;
            // 
            // txtHeight
            // 
            this.txtHeight.Location = new System.Drawing.Point(58, 60);
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Size = new System.Drawing.Size(100, 31);
            this.txtHeight.TabIndex = 10;
            // 
            // txtLenght
            // 
            this.txtLenght.Location = new System.Drawing.Point(235, 60);
            this.txtLenght.Name = "txtLenght";
            this.txtLenght.Size = new System.Drawing.Size(100, 31);
            this.txtLenght.TabIndex = 11;
            // 
            // txtWidth
            // 
            this.txtWidth.Location = new System.Drawing.Point(430, 60);
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.Size = new System.Drawing.Size(100, 31);
            this.txtWidth.TabIndex = 12;
            // 
            // txtRadius
            // 
            this.txtRadius.Location = new System.Drawing.Point(610, 60);
            this.txtRadius.Name = "txtRadius";
            this.txtRadius.Size = new System.Drawing.Size(100, 31);
            this.txtRadius.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(53, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 25);
            this.label4.TabIndex = 14;
            this.label4.Text = "Height";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(230, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 25);
            this.label5.TabIndex = 15;
            this.label5.Text = "Lenght";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(605, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 25);
            this.label6.TabIndex = 16;
            this.label6.Text = "Radius";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(425, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 25);
            this.label7.TabIndex = 17;
            this.label7.Text = "Width";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 551);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtRadius);
            this.Controls.Add(this.txtWidth);
            this.Controls.Add(this.txtLenght);
            this.Controls.Add(this.txtHeight);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCylinderA);
            this.Controls.Add(this.btnSphereA);
            this.Controls.Add(this.btnCubeA);
            this.Controls.Add(this.btnCylinder);
            this.Controls.Add(this.btnSphere);
            this.Controls.Add(this.btnCube);
            this.Name = "Form1";
            this.Text = "Volume & Area";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCube;
        private System.Windows.Forms.Button btnSphere;
        private System.Windows.Forms.Button btnCylinder;
        private System.Windows.Forms.Button btnCubeA;
        private System.Windows.Forms.Button btnSphereA;
        private System.Windows.Forms.Button btnCylinderA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.TextBox txtHeight;
        private System.Windows.Forms.TextBox txtLenght;
        private System.Windows.Forms.TextBox txtWidth;
        private System.Windows.Forms.TextBox txtRadius;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}

