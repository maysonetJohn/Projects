﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;

// Jonathan Maysonet Y00495534
// Nestor Vega Y00396433
// Edward Sasso Y00461818
// Jonathan Rosa Y00436324
// Mariaeliza Del Valle Y00477107

namespace AdvCLass6
{
    public class phpLink
    {
        public string responseStored = "";

       // string sLat = "18.123456";
       // string sLng = "-66.123456";

        public void phpRequest(string Type, string HEIGHT, string LENGTH, string WIDTH, string RADIUS)
        {
   
            WebRequest webRequest = WebRequest.Create("http://localhost/FormulasVA.php?" + "Type=" + Type + "&HEIGHT=" + HEIGHT + "&LENGTH=" + LENGTH + "&WIDTH=" + WIDTH + "&RADIUS=" + RADIUS);

            webRequest.Method = "GET";
            WebResponse webResponse = webRequest.GetResponse();

            Stream dataStream = webResponse.GetResponseStream();
            StreamReader reader = new StreamReader(dataStream);

            string responseFromServer = reader.ReadToEnd();

            responseStored = responseFromServer;

            reader.Close();
            dataStream.Close();
            webResponse.Close();
        }
    }
}