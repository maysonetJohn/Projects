﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdvCLass6;

// Jonathan Maysonet Y00495534
// Nestor Vega Y00396433
// Edward Sasso Y00461818
// Jonathan Rosa Y00436324
// Mariaeliza Del Valle Y00477107

namespace FormulasVolumen
{
    public partial class Form1 : Form
    {
        phpLink localPhpLink = new phpLink();
        string Type = "";
        public Form1()
        {
            InitializeComponent();
        }
 
        private void BtnCube_Click(object sender, EventArgs e)
        {
            Type = "Cube";
            localPhpLink.phpRequest(Type, txtHeight.Text, txtLenght.Text, txtWidth.Text, txtRadius.Text);
            lblResult.Text = localPhpLink.responseStored;
        }

        private void BtnSphere_Click(object sender, EventArgs e)
        {
            Type = "Sphere";
            localPhpLink.phpRequest(Type, txtHeight.Text, txtLenght.Text, txtWidth.Text, txtRadius.Text);
            lblResult.Text = localPhpLink.responseStored;
        }

        private void BtnCylinder_Click(object sender, EventArgs e)
        {
            Type = "Cylinder";
            localPhpLink.phpRequest(Type, txtHeight.Text, txtLenght.Text, txtWidth.Text, txtRadius.Text);
            lblResult.Text = localPhpLink.responseStored;
        }

        private void BtnCubeA_Click(object sender, EventArgs e)
        {
            Type = "CubeA";
            localPhpLink.phpRequest(Type, txtHeight.Text, txtLenght.Text, txtWidth.Text, txtRadius.Text);
            lblResult.Text = localPhpLink.responseStored;
        }

        private void BtnSpehereA_Click(object sender, EventArgs e)
        {
            Type = "SphereA";
            localPhpLink.phpRequest(Type, txtHeight.Text, txtLenght.Text, txtWidth.Text, txtRadius.Text);
            lblResult.Text = localPhpLink.responseStored;
        }

        private void BtnCylinderA_Click(object sender, EventArgs e)
        {
            Type = "CylinderA";
            localPhpLink.phpRequest(Type, txtHeight.Text, txtLenght.Text, txtWidth.Text, txtRadius.Text);
            lblResult.Text = localPhpLink.responseStored;
        }
        private void Label2_Click(object sender, EventArgs e)
        {

        }

    }
}
